package com.example.ailments;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod(AilmentsMod.MODID)
public class AilmentsMod {
    public static final String MODID = "ailments";

    public static final int AIR_MAX = 160;
    public static final ResourceLocation ANEMIA_MODIFIER =
            ResourceLocation.fromNamespaceAndPath(MODID, "anemia_health");

    public static final Map<UUID, String> DISEASE = new HashMap<>();
    public static final Map<UUID, Integer> AIR = new HashMap<>();
    public static final Map<UUID, Integer> ASTHMA_COOLDOWN = new HashMap<>();
    public static final Map<UUID, Boolean> AIR_WARNED = new HashMap<>();
    public static final Map<UUID, Double> LOWEST_Y = new HashMap<>();
    public static final Map<UUID, Boolean> WAS_ON_GROUND = new HashMap<>();
    public static final Map<UUID, Integer> HUNGER_COUNTER = new HashMap<>();

    public AilmentsMod() {
        NeoForge.EVENT_BUS.register(CommonHandlers.class);
        NeoForge.EVENT_BUS.register(CommandHandlers.class);
    }
}
