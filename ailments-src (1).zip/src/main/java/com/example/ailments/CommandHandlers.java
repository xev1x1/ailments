package com.example.ailments;

import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

public class CommandHandlers {

    private static final Set<String> DISEASES = Set.of("asthma", "arthritis", "anemia");

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
            .then(Commands.literal("give")
                .then(Commands.argument("disease", StringArgumentType.word())
                    .executes(ctx -> {
                        ServerPlayer p = ctx.getSource().getPlayerOrException();
                        String d = StringArgumentType.getString(ctx, "disease").toLowerCase(Locale.ROOT);
                        if (d.equals("none")) {
                            clear(p);
                            return 1;
                        }
                        if (!DISEASES.contains(d)) {
                            p.sendSystemMessage(Component.literal("Нет такой болезни: " + d
                                    + ". Доступно: asthma, arthritis, anemia, none."));
                            return 0;
                        }
                        apply(p, d);
                        return 1;
                    })))
            .then(Commands.literal("clear").executes(ctx -> {
                clear(ctx.getSource().getPlayerOrException());
                return 1;
            }))
            .then(Commands.literal("list").executes(ctx -> {
                ServerPlayer p = ctx.getSource().getPlayerOrException();
                p.sendSystemMessage(Component.literal("Доступно: asthma, arthritis, anemia, none. Сейчас у тебя: "
                        + AilmentsMod.DISEASE.getOrDefault(p.getUUID(), "none")));
                return 1;
            })));
    }

    private static void apply(ServerPlayer p, String d) {
        UUID u = p.getUUID();
        AilmentsMod.DISEASE.put(u, d);
        p.getPersistentData().putString("AilmentsDisease", d);
        AilmentsMod.AIR.put(u, AilmentsMod.AIR_MAX);

        if (d.equals("asthma")) {
            p.sendSystemMessage(Component.literal("Астма. Бег теперь тратит воздух: 8 секунд без остановки — и приступ. Прыжки во время бега приближают приступ."));
        } else if (d.equals("arthritis")) {
            p.sendSystemMessage(Component.literal("Артрит. Прострелы при беге, хруст коленей при прыжках и тяжёлые падения."));
        } else if (d.equals("anemia")) {
            p.sendSystemMessage(Component.literal("Анемия. Меньше здоровья и быстрее тратится голод."));
        }
    }

    private static void clear(ServerPlayer p) {
        UUID u = p.getUUID();
        AilmentsMod.DISEASE.put(u, "none");
        p.getPersistentData().putString("AilmentsDisease", "none");
        AttributeInstance attr = p.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            attr.removeModifier(AilmentsMod.ANEMIA_MODIFIER);
        }
        AilmentsMod.AIR.remove(u);
        AilmentsMod.HUNGER_COUNTER.remove(u);
        p.sendSystemMessage(Component.literal("Болезни сняты. Ты снова здоров."));
    }
}
