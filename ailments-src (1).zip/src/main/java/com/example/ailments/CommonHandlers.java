package com.example.ailments;

import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

public class CommonHandlers {

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        UUID u = p.getUUID();
        String d = AilmentsMod.DISEASE.getOrDefault(u, "none");

        switch (d) {
            case "asthma" -> tickAsthma(p, u);
            case "arthritis" -> tickArthritis(p, u);
            case "anemia" -> tickAnemia(p, u);
            default -> {
                AttributeInstance attr = p.getAttribute(Attributes.MAX_HEALTH);
                if (attr != null && attr.getModifier(AilmentsMod.ANEMIA_MODIFIER) != null) {
                    attr.removeModifier(AilmentsMod.ANEMIA_MODIFIER);
                }
                AilmentsMod.AIR.remove(u);
            }
        }
    }

    private static void tickAsthma(ServerPlayer p, UUID u) {
        int air = AilmentsMod.AIR.getOrDefault(u, AilmentsMod.AIR_MAX);
        boolean sprinting = p.isSprinting();
        boolean inWater = p.isInWater();

        if (sprinting) {
            air -= inWater ? 3 : 1;
        } else if (inWater) {
            air -= 2;
        } else {
            air = Math.min(AilmentsMod.AIR_MAX, air + 2);
        }
        air = Math.max(0, air);
        AilmentsMod.AIR.put(u, air);

        if (air < 50 && !AilmentsMod.AIR_WARNED.getOrDefault(u, false)) {
            AilmentsMod.AIR_WARNED.put(u, true);
            p.sendSystemMessage(Component.literal("Дыхание сбивается... стоит остановиться."));
        }
        if (air >= 100) {
            AilmentsMod.AIR_WARNED.put(u, false);
        }

        if (air > 0 && air < AilmentsMod.AIR_MAX) {
            int bars = (int) Math.ceil(air * 10.0 / AilmentsMod.AIR_MAX);
            StringBuilder sb = new StringBuilder("Воздух: ");
            for (int i = 0; i < 10; i++) {
                sb.append(i < bars ? "\u25AE" : "\u25AF");
            }
            p.displayClientMessage(Component.literal(sb.toString()), true);
        }

        int cd = AilmentsMod.ASTHMA_COOLDOWN.getOrDefault(u, 0);
        if (cd > 0) {
            AilmentsMod.ASTHMA_COOLDOWN.put(u, cd - 1);
        }

        if (air <= 0 && cd <= 0) {
            asthmaAttack(p, u);
        }
    }

    private static void asthmaAttack(ServerPlayer p, UUID u) {
        p.setSprinting(false);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
        p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
        p.sendSystemMessage(Component.literal("Астматический приступ! Ноги ватные, надо отдышаться."));
        AilmentsMod.AIR.put(u, 60);
        AilmentsMod.ASTHMA_COOLDOWN.put(u, 100);
    }

    private static void tickArthritis(ServerPlayer p, UUID u) {
        boolean onGround = p.onGround();
        double y = p.getY();

        if (!onGround) {
            AilmentsMod.LOWEST_Y.merge(u, y, Math::min);
        } else if (!AilmentsMod.WAS_ON_GROUND.getOrDefault(u, true)) {
            double fall = AilmentsMod.LOWEST_Y.getOrDefault(u, y) - y;
            AilmentsMod.LOWEST_Y.remove(u);
            if (fall > 2.5 && p.getRandom().nextDouble() < 0.35) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                p.sendSystemMessage(Component.literal("Колени хрустнули от жёсткого приземления!"));
            }
        }
        AilmentsMod.WAS_ON_GROUND.put(u, onGround);

        if (p.isSprinting() && p.getRandom().nextDouble() < 0.0025) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 0));
            p.sendSystemMessage(Component.literal("Суставы прострелило — бег даётся тяжелее."));
        }
    }

    private static void tickAnemia(ServerPlayer p, UUID u) {
        AttributeInstance attr = p.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && attr.getModifier(AilmentsMod.ANEMIA_MODIFIER) == null) {
            attr.addTransientModifier(new AttributeModifier(
                    AilmentsMod.ANEMIA_MODIFIER, -8.0, AttributeModifier.Operation.ADD_VALUE));
            p.sendSystemMessage(Component.literal("Анемия: организм ослаблен, минус четыре сердца."));
        }

        int c = AilmentsMod.HUNGER_COUNTER.getOrDefault(u, 0) + 1;
        if (c >= 300) {
            c = 0;
            if (p.getFoodData().getFoodLevel() > 0) {
                p.getFoodData().setFoodLevel(p.getFoodData().getFoodLevel() - 1);
            }
        }
        AilmentsMod.HUNGER_COUNTER.put(u, c);

        if (p.getRandom().nextDouble() < 1.0 / 800) {
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0));
            p.sendSystemMessage(Component.literal("В глазах потемнело... передохни немного."));
        }
    }

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent event) {
        LivingEntity e = event.getEntity();
        if (e.level().isClientSide || !(e instanceof ServerPlayer p)) return;
        UUID u = p.getUUID();
        String d = AilmentsMod.DISEASE.getOrDefault(u, "none");

        if (d.equals("asthma") && p.isSprinting()) {
            AilmentsMod.AIR.computeIfPresent(u, (k, v) -> Math.max(0, v - 10));
        }

        if (d.equals("arthritis") && p.getRandom().nextDouble() < 0.15) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0));
            p.sendSystemMessage(Component.literal("Колени хрустнули при прыжке."));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        UUID u = p.getUUID();
        String d = p.getPersistentData().getString("AilmentsDisease");
        String real = d.isEmpty() ? "none" : d;
        AilmentsMod.DISEASE.put(u, real);
        if (!real.equals("none")) {
            p.sendSystemMessage(Component.literal("Хроническое состояние сохранено: " + real));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        UUID u = p.getUUID();
        AilmentsMod.DISEASE.remove(u);
        AilmentsMod.AIR.remove(u);
        AilmentsMod.ASTHMA_COOLDOWN.remove(u);
        AilmentsMod.AIR_WARNED.remove(u);
        AilmentsMod.LOWEST_Y.remove(u);
        AilmentsMod.WAS_ON_GROUND.remove(u);
        AilmentsMod.HUNGER_COUNTER.remove(u);
    }
}
