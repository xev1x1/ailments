# Ailments

Mod for Minecraft 1.21.1 (NeoForge).

## Commands (operator permission required)
- /ailments give <player> <asthma|arthritis|anemia>
- /ailments clear <player>

## Build
Built via GitHub Actions. Output: build/libs/ailments-1.0.0.jar
