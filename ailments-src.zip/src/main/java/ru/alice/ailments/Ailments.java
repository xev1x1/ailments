package ru.alice.ailments;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@Mod(Ailments.MODID)
public class Ailments {

    public static final String MODID = "ailments";

    // Keys in the player's persistent data
    private static final String K_ASTHMA = "ailments_asthma";
    private static final String K_ASTHMA_ATTACK = "ailments_asthma_attack";
    private static final String K_ASTHMA_SPRINT = "ailments_asthma_sprint";
    private static final String K_ASTHMA_TICKS = "ailments_asthma_ticks";
    private static final String K_ARTHRITIS = "ailments_arthritis";
    private static final String K_ARTHRITIS_TICKS = "ailments_arthritis_ticks";
    private static final String K_ANEMIA = "ailments_anemia";

    // Tuning: 8 seconds of sprint = 160 ticks, attack lasts 5 s = 100 ticks
    private static final int ASTHMA_SPRINT_LIMIT = 160;
    private static final int ASTHMA_ATTACK_TICKS = 100;
    private static final int ARTHRITIS_SLOW_TICKS = 40;
    private static final float ANEMIA_HEALTH_CAP = 12.0F; // 6 hearts instead of 10

    public Ailments() {
        NeoForge.EVENT_BUS.register(this.getClass());
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide) {
            return;
        }
        CompoundTag data = player.getPersistentData();

        // ASTHMA: after 8 s of non-stop sprinting, an attack interrupts running
        if (data.getBoolean(K_ASTHMA)) {
            if (data.getBoolean(K_ASTHMA_ATTACK)) {
                player.setSprinting(false);
                int left = data.getInt(K_ASTHMA_TICKS);
                if (left <= 1) {
                    data.putBoolean(K_ASTHMA_ATTACK, false);
                    data.putInt(K_ASTHMA_SPRINT, 0);
                    msg(player, "Asthma attack over. You can breathe again.");
                } else {
                    data.putInt(K_ASTHMA_TICKS, left - 1);
                }
            } else if (player.isSprinting()) {
                int sprint = data.getInt(K_ASTHMA_SPRINT) + 1;
                if (sprint >= ASTHMA_SPRINT_LIMIT) {
                    data.putBoolean(K_ASTHMA_ATTACK, true);
                    data.putInt(K_ASTHMA_TICKS, ASTHMA_ATTACK_TICKS);
                    msg(player, "Asthma attack! You cannot sprint right now.");
                } else {
                    data.putInt(K_ASTHMA_SPRINT, sprint);
                }
            } else {
                data.putInt(K_ASTHMA_SPRINT, 0);
            }
        }

        // ARTHRITIS: falling from 2+ blocks slows movement for a short while
        if (data.getBoolean(K_ARTHRITIS)) {
            int slow = data.getInt(K_ARTHRITIS_TICKS);
            if (slow > 0) {
                player.setDeltaMovement(player.getDeltaMovement().multiply(0.5, 1.0, 0.5));
                data.putInt(K_ARTHRITIS_TICKS, slow - 1);
            }
            if (player.onGround() && player.fallDistance >= 2.0F) {
                player.fallDistance = 0.0F;
                data.putInt(K_ARTHRITIS_TICKS, ARTHRITIS_SLOW_TICKS);
                msg(player, "Your knees ache from that fall.");
            }
        }

        // ANEMIA: health is capped at 6 hearts
        if (data.getBoolean(K_ANEMIA) && player.getHealth() > ANEMIA_HEALTH_CAP) {
            player.setHealth(ANEMIA_HEALTH_CAP);
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("ailments")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("give")
                        .then(Commands.argument("disease", StringArgumentType.word())
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(ctx -> give(
                                                ctx.getSource(),
                                                StringArgumentType.getString(ctx, "disease"),
                                                EntityArgument.getPlayer(ctx, "player"))))))
                .then(Commands.literal("clear")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> clear(
                                        ctx.getSource(),
                                        EntityArgument.getPlayer(ctx, "player"))))));
    }

    private static int give(CommandSourceStack source, String disease, Player player) {
        CompoundTag data = player.getPersistentData();
        switch (disease.toLowerCase()) {
            case "asthma" -> data.putBoolean(K_ASTHMA, true);
            case "arthritis" -> data.putBoolean(K_ARTHRITIS, true);
            case "anemia" -> data.putBoolean(K_ANEMIA, true);
            default -> {
                source.sendFailure(Component.literal("Unknown disease: " + disease
                        + ". Use asthma, arthritis or anemia."));
                return 0;
            }
        }
        source.sendSuccess(() -> Component.literal("[Ailments] Gave " + disease + " to "
                + player.getName().getString() + "."), true);
        return 1;
    }

    private static int clear(CommandSourceStack source, Player player) {
        CompoundTag data = player.getPersistentData();
        data.putBoolean(K_ASTHMA, false);
        data.putBoolean(K_ASTHMA_ATTACK, false);
        data.putInt(K_ASTHMA_SPRINT, 0);
        data.putInt(K_ASTHMA_TICKS, 0);
        data.putBoolean(K_ARTHRITIS, false);
        data.putInt(K_ARTHRITIS_TICKS, 0);
        data.putBoolean(K_ANEMIA, false);
        source.sendSuccess(() -> Component.literal("[Ailments] Cleared all ailments from "
                + player.getName().getString() + "."), true);
        return 1;
    }

    private static void msg(Player player, String text) {
        player.displayClientMessage(Component.literal("[Ailments] " + text), true);
    }
}
