package ru.alice.ailments;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Mod(Ailments.MODID)
public class Ailments {

    public static final String MODID = "ailments";

    private static final String ASTHMA = "asthma";
    private static final String ARTHRITIS = "arthritis";
    private static final String ANEMIA = "anemia";

    private static final ResourceLocation ANEMIA_HEALTH_ID =
            ResourceLocation.fromNamespaceAndPath(MODID, "anemia_health");

    // 8 seconds of sprinting = 160 ticks, after that the asthma attack
    private static final int ASTHMA_SPRINT_LIMIT_TICKS = 160;

    private final Map<UUID, Integer> sprintTicks = new HashMap<>();
    private final Map<UUID, Set<String>> ailments = new HashMap<>();

    public Ailments() {
        NeoForge.EVENT_BUS.register(this);
    }

    // ---------- give / clear ----------

    private boolean give(Player player, String ailment) {
        if (!ASTHMA.equals(ailment) && !ARTHRITIS.equals(ailment) && !ANEMIA.equals(ailment)) {
            return false;
        }
        ailments.computeIfAbsent(player.getUUID(), k -> new HashSet<>()).add(ailment);
        if (ANEMIA.equals(ailment)) {
            applyAnemia(player);
        }
        player.displayClientMessage(Component.literal("Bolezn: " + ailment), false);
        return true;
    }

    private void clear(Player player) {
        ailments.remove(player.getUUID());
        sprintTicks.remove(player.getUUID());
        removeAnemia(player);
        player.displayClientMessage(Component.literal("All diseases removed"), false);
    }

    // ---------- anemia: minus 4 hearts ----------

    private void applyAnemia(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && !attr.hasModifier(ANEMIA_HEALTH_ID)) {
            attr.addPermanentModifier(new AttributeModifier(ANEMIA_HEALTH_ID, -8.0D, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    private void removeAnemia(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && attr.hasModifier(ANEMIA_HEALTH_ID)) {
            attr.removeModifier(ANEMIA_HEALTH_ID);
        }
    }

    // ---------- player tick: asthma and anemia ----------

    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) {
            return;
        }
        Set<String> active = ailments.get(player.getUUID());
        if (active == null || active.isEmpty()) {
            return;
        }
        UUID id = player.getUUID();

        if (active.contains(ANEMIA)) {
            applyAnemia(player);
            if (player.isSprinting()) {
                int t = sprintTicks.merge(id, 1, Integer::sum);
                if (t % 60 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
                    player.displayClientMessage(Component.literal("Eyes go dark..."), true);
                }
            } else {
                sprintTicks.remove(id);
            }
        }

        if (active.contains(ASTHMA)) {
            if (player.isSprinting()) {
                int t = sprintTicks.merge(id, 1, Integer::sum);
                if (t >= ASTHMA_SPRINT_LIMIT_TICKS) {
                    sprintTicks.put(id, 0);
                    player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                    player.displayClientMessage(Component.literal("Attack! Breathing: 0/8 sec"), true);
                } else if (t % 20 == 0) {
                    player.displayClientMessage(Component.literal(
                            "Breathing: " + (ASTHMA_SPRINT_LIMIT_TICKS - t) / 20 + "/8"), true);
                }
            } else {
                sprintTicks.remove(id);
            }
        }
    }

    // ---------- arthritis: knees crack after a 2+ block fall ----------

    @SubscribeEvent
    public void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide()) {
            return;
        }
        Set<String> active = ailments.get(player.getUUID());
        if (active == null || !active.contains(ARTHRITIS)) {
            return;
        }
        if (event.getDistance() >= 2.0F) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 0));
            player.displayClientMessage(Component.literal("Knees cracked..."), true);
        }
    }

    // ---------- /ailments give|clear ----------

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("give")
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("ailment", StringArgumentType.word())
                                        .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                                List.of(ASTHMA, ARTHRITIS, ANEMIA), builder))
                                        .executes(ctx -> {
                                            Player target = EntityArgument.getPlayer(ctx, "player");
                                            String ailment = StringArgumentType.getString(ctx, "ailment");
                                            if (!give(target, ailment)) {
                                                ctx.getSource().sendFailure(Component.literal(
                                                        "Unknown disease: " + ailment
                                                                + " (available: asthma, arthritis, anemia)"));
                                                return 0;
                                            }
                                            ctx.getSource().sendSuccess(() -> Component.literal(
                                                    target.getName().getString() + " got: " + ailment), true);
                                            return 1;
                                        }))))
                .then(Commands.literal("clear")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> {
                                    Player target = EntityArgument.getPlayer(ctx, "player");
                                    clear(target);
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            target.getName().getString() + " is healthy again"), true);
                                    return 1;
                                }))));
    }
}