package ru.alice.ailments;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Mod(Ailments.MODID)
public final class Ailments {

    public static final String MODID = "ailments";

    private static final String K_ASTHMA = "ailments_asthma";
    private static final String K_ARTHRITIS = "ailments_arthritis";
    private static final String K_ANEMIA = "ailments_anemia";

    private static final int SPRINT_LIMIT_TICKS = 160;      // 8 s of running -> attack
    private static final int ASTHMA_ATTACK_TICKS = 60;      // 3 s attack
    private static final int ARTHRITIS_STIFFNESS_TICKS = 60;
    private static final float ARTHRITIS_FALL_MIN = 2.0F;
    private static final int DARKNESS_REFRESH_TICKS = 30;

    private final Map<UUID, Long> sprintStart = new HashMap<>();
    private final Map<UUID, Integer> asthmaAttack = new HashMap<>();
    private final Map<UUID, Float> prevFall = new HashMap<>();
    private final Map<UUID, Boolean> prevGround = new HashMap<>();
    private final Map<UUID, Integer> darknessTick = new HashMap<>();

    public Ailments(IEventBus modEventBus) {
        NeoForge.EVENT_BUS.register(this);
    }

    private static Optional<Holder<MobEffect>> effect(String path) {
        return BuiltInRegistries.MOB_EFFECT.getHolder(Identifier.of("minecraft", path));
    }

    private static void applyEffect(Player player, String path, int duration, int amplifier) {
        effect(path).ifPresent(h -> player.addEffect(new MobEffectInstance(h, duration, amplifier)));
    }

    private static boolean has(Player p, String key) {
        return p.getPersistentData().getBoolean(key);
    }

    private static void set(Player p, String key, boolean value) {
        p.getPersistentData().putBoolean(key, value);
    }

    private static void capHealth(Player p) {
        AttributeInstance attr = p.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && attr.getBaseValue() > 12.0) {
            attr.setBaseValue(12.0);
            if (p.getHealth() > 12.0F) {
                p.setHealth(12.0F);
            }
        }
    }

    private static void restoreHealth(Player p) {
        AttributeInstance attr = p.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            attr.setBaseValue(20.0);
        }
    }

    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) {
            return;
        }
        UUID id = player.getUUID();

        if (has(player, K_ASTHMA)) {
            tickAsthma(player, id);
        }
        if (has(player, K_ANEMIA)) {
            capHealth(player);
            tickAnemia(player, id);
        }
        tickArthritis(player, id);
    }

    private void tickAsthma(Player player, UUID id) {
        long now = player.level().getGameTime();
        if (player.isSprinting()) {
            long start = sprintStart.computeIfAbsent(id, k -> now);
            int attack = asthmaAttack.getOrDefault(id, 0);
            if (attack <= 0 && now - start >= SPRINT_LIMIT_TICKS) {
                asthmaAttack.put(id, ASTHMA_ATTACK_TICKS);
                player.setSprinting(false);
                applyEffect(player, "slowness", ASTHMA_ATTACK_TICKS, 1);
                player.displayClientMessage(Component.literal("Asthma attack! Catching your breath..."), true);
            }
        } else {
            sprintStart.remove(id);
        }
        int attack = asthmaAttack.getOrDefault(id, 0);
        if (attack > 0) {
            asthmaAttack.put(id, attack - 1);
            if (player.isSprinting()) {
                player.setSprinting(false);
            }
        }
    }

    private void tickArthritis(Player player, UUID id) {
        boolean ground = player.onGround();
        float fall = player.fallDistance;
        boolean wasGround = prevGround.getOrDefault(id, true);
        float wasFall = prevFall.getOrDefault(id, 0.0F);
        if (ground && !wasGround && wasFall >= ARTHRITIS_FALL_MIN) {
            applyEffect(player, "slowness", ARTHRITIS_STIFFNESS_TICKS, 0);
            player.displayClientMessage(Component.literal("Your knees ache after that landing."), true);
        }
        prevFall.put(id, fall);
        prevGround.put(id, ground);
    }

    private void tickAnemia(Player player, UUID id) {
        if (player.isSprinting()) {
            int tick = darknessTick.getOrDefault(id, 0);
            if (tick <= 0) {
                applyEffect(player, "darkness", 60, 0);
            }
            darknessTick.put(id, (tick + 1) % DARKNESS_REFRESH_TICKS);
        } else {
            darknessTick.remove(id);
        }
    }

    @SubscribeEvent
    public void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof Player player && !player.level().isClientSide()) {
            if (has(player, K_ANEMIA)) {
                capHealth(player);
            }
        }
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("give")
                        .then(Commands.argument("disease", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        new String[]{"asthma", "arthritis", "anemia"}, builder))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(this::give))))
                .then(Commands.literal("clear")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(this::clear))));
    }

    private int give(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        Player target = EntityArgument.getPlayer(ctx, "player");
        String disease = StringArgumentType.getString(ctx, "disease").toLowerCase();
        switch (disease) {
            case "asthma" -> set(target, K_ASTHMA, true);
            case "arthritis" -> set(target, K_ARTHRITIS, true);
            case "anemia" -> {
                set(target, K_ANEMIA, true);
                capHealth(target);
            }
            default -> {
                ctx.getSource().sendFailure(Component.literal("Unknown disease: " + disease));
                return 0;
            }
        }
        ctx.getSource().sendSuccess(() -> Component.literal(
                "Gave " + target.getName().getString() + " the disease: " + disease), true);
        return 1;
    }

    private int clear(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        Player target = EntityArgument.getPlayer(ctx, "player");
        set(target, K_ASTHMA, false);
        set(target, K_ARTHRITIS, false);
        set(target, K_ANEMIA, false);
        restoreHealth(target);
        effect("slowness").ifPresent(target::removeEffect);
        effect("darkness").ifPresent(target::removeEffect);
        sprintStart.remove(target.getUUID());
        asthmaAttack.remove(target.getUUID());
        darknessTick.remove(target.getUUID());
        ctx.getSource().sendSuccess(() -> Component.literal(
                target.getName().getString() + " is healthy again."), true);
        return 1;
    }
}
