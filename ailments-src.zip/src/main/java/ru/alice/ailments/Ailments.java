package ru.alice.ailments;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.Holder;
import net.minecraft.core.Identifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@Mod(Ailments.MODID)
public class Ailments {
    public static final String MODID = "ailments";

    private static final String KEY_ASTHMA = "ailments_asthma";
    private static final String KEY_ARTHRITIS = "ailments_arthritis";
    private static final String KEY_ANEMIA = "ailments_anemia";
    private static final String KEY_RUN_TICKS = "ailments_run_ticks";

    // 8 секунд бега = 160 тиков
    private static final int RUN_LIMIT = 160;

    private static final Identifier ANEMIA_ID = Identifier.fromNamespaceAndPath(MODID, "anemia_health");

    public Ailments() {
        NeoForge.EVENT_BUS.register(this);
    }

    // Эффекты берём из реестра по идентификатору, а не по имени Java-константы:
    // имена полей Mojang переименование меняет, идентификаторы эффектов — нет.
    private static Holder<MobEffect> effect(String name) {
        return BuiltInRegistries.MOB_EFFECT.getHolder(Identifier.withDefaultNamespace(name)).orElse(null);
    }

    private static void apply(Player p, String effectName, int durationTicks, int amplifier) {
        Holder<MobEffect> e = effect(effectName);
        if (e != null) {
            p.addEffect(new MobEffectInstance(e, durationTicks, amplifier));
        }
    }

    private static void msg(Player p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    // --- АСТМА и АНЕМИЯ: тики игрока ---
    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        Player p = event.getEntity();
        if (p.level().isClientSide) return;

        CompoundTag d = p.getPersistentData();

        // Астма: копим время бега, на пределе рвём спринт и вешаем Slowness II на 3 секунды
        if (d.getBoolean(KEY_ASTHMA) && p.isSprinting()) {
            int ticks = d.getInt(KEY_RUN_TICKS) + 1;
            if (ticks >= RUN_LIMIT) {
                ticks = 0;
                p.setSprinting(false);
                apply(p, "slowness", 60, 1);
                msg(p, "\u00a77Приступ астмы. Отдышись.");
            }
            d.putInt(KEY_RUN_TICKS, ticks);
        } else if (!p.isSprinting() && d.getInt(KEY_RUN_TICKS) > 0) {
            // Отдыхаем — счётчик медленно откатывается
            d.putInt(KEY_RUN_TICKS, Math.max(0, d.getInt(KEY_RUN_TICKS) - 2));
        }

        // Анемия: при беге затемнение краёв экрана (Darkness), обновляем раз в 1,5 секунды
        if (d.getBoolean(KEY_ANEMIA) && p.isSprinting() && p.tickCount % 30 == 0) {
            apply(p, "darkness", 50, 0);
        }
    }

    // --- АРТРИТ: падение с 2+ блоков ---
    @SubscribeEvent
    public void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof Player p)) return;
        if (p.level().isClientSide) return;
        if (p.getPersistentData().getBoolean(KEY_ARTHRITIS) && event.getFallDistance() >= 2.0F) {
            apply(p, "slowness", 60, 0);
            msg(p, "\u00a77Колени хрустят...");
        }
    }

    // --- АНЕМИЯ: -4 сердца к максимуму (10 -> 6) ---
    @SubscribeEvent
    public void onJoin(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof Player p && !p.level().isClientSide) {
            applyAnemia(p, p.getPersistentData().getBoolean(KEY_ANEMIA));
        }
    }

    private static void applyAnemia(Player p, boolean on) {
        AttributeInstance attr = p.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        AttributeModifier existing = attr.getModifier(ANEMIA_ID);
        if (on && existing == null) {
            attr.addPermanentModifier(new AttributeModifier(ANEMIA_ID, -8.0, AttributeModifier.Operation.ADD_VALUE));
            p.setHealth((float) Math.min(p.getHealth(), p.getMaxHealth()));
        } else if (!on && existing != null) {
            attr.removeModifier(ANEMIA_ID);
        }
    }

    // --- Команды: /ailments give <болезнь> <игрок>, /ailments clear <игрок> ---
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
            .requires(src -> src.hasPermission(2))
            .then(Commands.literal("give")
                .then(Commands.argument("ailment", StringArgumentType.word())
                    .then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> {
                            String ailment = StringArgumentType.getString(ctx, "ailment").toLowerCase();
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            String key;
                            switch (ailment) {
                                case "asthma": case "астма": key = KEY_ASTHMA; break;
                                case "arthritis": case "артрит": key = KEY_ARTHRITIS; break;
                                case "anemia": case "анемия": key = KEY_ANEMIA; break;
                                default:
                                    ctx.getSource().sendFailure(Component.literal("Нет такой болезни: " + ailment));
                                    return 0;
                            }
                            target.getPersistentData().putBoolean(key, true);
                            if (key.equals(KEY_ANEMIA)) applyAnemia(target, true);
                            final String shown = ailment;
                            ctx.getSource().sendSuccess(() -> Component.literal("Выдано: " + shown), true);
                            return 1;
                        }))))
            .then(Commands.literal("clear")
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(ctx -> {
                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                        CompoundTag d = target.getPersistentData();
                        d.putBoolean(KEY_ASTHMA, false);
                        d.putBoolean(KEY_ARTHRITIS, false);
                        d.putBoolean(KEY_ANEMIA, false);
                        d.putInt(KEY_RUN_TICKS, 0);
                        applyAnemia(target, false);
                        ctx.getSource().sendSuccess(() -> Component.literal("Все болезни сняты."), true);
                        return 1;
                    }))));
    }
}
