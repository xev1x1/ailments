package ru.alice.ailments;

import com.mojang.brigadier.arguments.StringArgumentType;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@Mod(Ailments.MODID)
@EventBusSubscriber(modid = Ailments.MODID)
public class Ailments {

    public static final String MODID = "ailments";

    private static final String TAG_ASTHMA = "ailments:asthma";
    private static final String TAG_ARTHRITIS = "ailments:arthritis";
    private static final String TAG_ANEMIA = "ailments:anemia";

    private static final int SPRINT_LIMIT = 160;   // 8 секунд бега подряд
    private static final int ATTACK_TICKS = 100;   // приступ длится 5 секунд
    private static final float LIMP_FALL = 2.0F;   // падение с 2+ блоков

    private static final Map<UUID, State> STATES = new HashMap<>();

    public Ailments() {
    }

    private static final class State {
        int sprintTicks;
        int attackTicks;
        float prevFall;
    }

    private static State state(ServerPlayer player) {
        return STATES.computeIfAbsent(player.getUUID(), k -> new State());
    }

    private static boolean has(ServerPlayer player, String tag) {
        return player.getPersistentData().getBoolean(tag);
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        State s = state(player);

        if (has(player, TAG_ANEMIA)) {
            applyAnemia(player);
            if (player.isSprinting()) {
                player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, true, false));
            }
        }

        if (has(player, TAG_ARTHRITIS)) {
            if (player.onGround()) {
                if (s.prevFall >= LIMP_FALL) {
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, true));
                    player.displayClientMessage(Component.literal("Колени хрустят после прыжка..."), true);
                }
                s.prevFall = 0.0F;
            } else {
                s.prevFall = player.fallDistance;
            }
        }

        if (has(player, TAG_ASTHMA)) {
            if (s.attackTicks > 0) {
                s.attackTicks--;
                if (player.isSprinting()) {
                    player.setSprinting(false);
                }
                int bars = Math.max(1, (s.attackTicks + 9) / 10);
                String meter = "█".repeat(bars) + "░".repeat(10 - bars);
                player.displayClientMessage(Component.literal("Дыхание: " + meter), true);
                if (s.attackTicks == 0) {
                    player.displayClientMessage(Component.literal("Приступ миновал."), true);
                }
            } else if (player.isSprinting()) {
                s.sprintTicks++;
                if (s.sprintTicks >= SPRINT_LIMIT) {
                    s.sprintTicks = 0;
                    s.attackTicks = ATTACK_TICKS;
                    player.displayClientMessage(Component.literal("Приступ астмы! Бег прерван."), true);
                }
            } else {
                s.sprintTicks = 0;
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerJoin(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && has(player, TAG_ANEMIA)) {
            applyAnemia(player);
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("give")
                        .then(Commands.argument("disease", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        List.of("asthma", "arthritis", "anemia"), builder))
                                .then(Commands.argument("target", EntityArgument.player())
                                        .executes(ctx -> {
                                            ServerPlayer target = EntityArgument.getPlayer(ctx, "target");
                                            String disease = StringArgumentType.getString(ctx, "disease")
                                                    .toLowerCase(Locale.ROOT);
                                            switch (disease) {
                                                case "asthma" -> target.getPersistentData().putBoolean(TAG_ASTHMA, true);
                                                case "arthritis" -> target.getPersistentData().putBoolean(TAG_ARTHRITIS, true);
                                                case "anemia" -> {
                                                    target.getPersistentData().putBoolean(TAG_ANEMIA, true);
                                                    applyAnemia(target);
                                                }
                                                default -> {
                                                    ctx.getSource().sendFailure(
                                                            Component.literal("Нет такой болезни: " + disease));
                                                    return 0;
                                                }
                                            }
                                            String name = target.getName().getString();
                                            ctx.getSource().sendSuccess(
                                                    () -> Component.literal("Выдал болезнь " + disease + " игроку " + name),
                                                    true);
                                            return 1;
                                        }))))
                .then(Commands.literal("clear")
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(ctx -> {
                                    ServerPlayer target = EntityArgument.getPlayer(ctx, "target");
                                    target.getPersistentData().remove(TAG_ASTHMA);
                                    target.getPersistentData().remove(TAG_ARTHRITIS);
                                    target.getPersistentData().remove(TAG_ANEMIA);
                                    clearAnemia(target);
                                    target.removeEffect(MobEffects.DARKNESS);
                                    target.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                                    String name = target.getName().getString();
                                    ctx.getSource().sendSuccess(
                                            () -> Component.literal("Вылечил игрока " + name), true);
                                    return 1;
                                }))));
    }

    private static void applyAnemia(ServerPlayer player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && Math.abs(attr.getBaseValue() - 12.0D) > 0.01D) {
            attr.setBaseValue(12.0D);
            if (player.getHealth() > 12.0F) {
                player.setHealth(12.0F);
            }
        }
    }

    private static void clearAnemia(ServerPlayer player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && Math.abs(attr.getBaseValue() - 20.0D) > 0.01D) {
            attr.setBaseValue(20.0D);
        }
    }
}
