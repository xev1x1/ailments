package com.example.ailments;

import java.util.Random;

import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Chronic diseases: once contracted, a disease stays with the player
 * until cured with /ailments cure. Diseases survive death and relog.
 */
public class AilmentTimer {

    /** Interval between "checkup" rolls, in ticks. 6000 ticks = 5 minutes. */
    public static int intervalTicks = 6000;

    /** Chance (percent) to contract a disease at each checkup. */
    public static int chancePercent = 30;

    private static final String ROOT_KEY = Player.PERSISTED_NBT_TAG;
    private static final String KEY_TIMER = "AilmentsTimer";
    private static final String KEY_DISEASE = "AilmentsDisease";
    private static final String KEY_PREV_SPRINT = "AilmentsPrevSprint";

    private static final Random RANDOM = new Random();
    private static final String[] AILMENTS = {"asthma", "fever", "vertigo"};

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide || player.isCreative() || player.isSpectator()) {
            return;
        }

        CompoundTag root = player.getPersistentData();
        CompoundTag data = root.contains(ROOT_KEY) ? root.getCompound(ROOT_KEY) : new CompoundTag();
        if (!root.contains(ROOT_KEY)) {
            root.put(ROOT_KEY, data);
        }

        String disease = data.getString(KEY_DISEASE);
        if (!disease.isEmpty()) {
            tickDisease(player, disease, data);
        }

        // Checkup: once per interval, roll the dice for a new chronic disease.
        int ticks = data.getInt(KEY_TIMER) + 1;
        if (ticks >= intervalTicks) {
            ticks = 0;
            if (disease.isEmpty() && RANDOM.nextInt(100) < chancePercent) {
                String picked = AILMENTS[RANDOM.nextInt(AILMENTS.length)];
                data.putString(KEY_DISEASE, picked);
                player.sendSystemMessage(Component.literal(announce(picked)));
            }
        }
        data.putInt(KEY_TIMER, ticks);
    }

    private static void tickDisease(Player player, String disease, CompoundTag data) {
        switch (disease) {
            case "asthma" -> {
                boolean sprinting = player.isSprinting();
                if (sprinting) {
                    // Like drowning on land: air drains while running.
                    int air = Math.max(0, player.getAirSupply() - 2);
                    player.setAirSupply(air);
                    if (air <= 60) {
                        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, true, false));
                    }
                    if (air <= 20) {
                        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, true, false));
                    }
                    if (air <= 0) {
                        player.hurt(player.damageSources().drowning(), 1.0F);
                    }
                } else {
                    // Standing still: breathing recovers.
                    if (player.getAirSupply() < player.getMaxAirSupply()) {
                        player.setAirSupply(Math.min(player.getMaxAirSupply(), player.getAirSupply() + 2));
                    }
                    // Sudden stop after running: shortness of breath.
                    if (data.getBoolean(KEY_PREV_SPRINT)) {
                        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0, true, false));
                    }
                }
                data.putBoolean(KEY_PREV_SPRINT, sprinting);
            }
            case "fever" -> {
                if (player.tickCount % 200 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 600, 0, true, false));
                    if (RANDOM.nextInt(3) == 0) {
                        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 300, 0, true, false));
                    }
                }
            }
            case "vertigo" -> {
                if (player.tickCount % 300 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0, true, false));
                    if (RANDOM.nextInt(4) == 0) {
                        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1, true, false));
                    }
                }
            }
        }
    }

    private static String announce(String disease) {
        return switch (disease) {
            case "asthma" -> "В груди сжимается... У тебя астма. Бег теперь даётся тяжело. Вылечить: /ailments cure";
            case "fever" -> "Ты чувствуешь жар. Хроническая лихорадка! Вылечить: /ailments cure";
            case "vertigo" -> "Мир плывёт перед глазами. Хроническое головокружение! Вылечить: /ailments cure";
            default -> disease;
        };
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
            .requires(source -> source.hasPermission(2))
            .then(Commands.literal("interval")
                .then(Commands.argument("minutes", IntegerArgumentType.integer(1, 120))
                    .executes(context -> {
                        intervalTicks = IntegerArgumentType.getInteger(context, "minutes") * 60 * 20;
                        context.getSource().sendSuccess(
                            () -> Component.literal("Проверка на болезни: раз в " + (intervalTicks / 1200) + " мин."), true);
                        return 1;
                    })))
            .then(Commands.literal("chance")
                .then(Commands.argument("percent", IntegerArgumentType.integer(0, 100))
                    .executes(context -> {
                        chancePercent = IntegerArgumentType.getInteger(context, "percent");
                        context.getSource().sendSuccess(
                            () -> Component.literal("Шанс заразиться за проверку: " + chancePercent + "%."), true);
                        return 1;
                    })))
            .then(Commands.literal("give")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("disease", IntegerArgumentType.integer(0, 2))
                        .executes(context -> {
                            ServerPlayer target = EntityArgument.getPlayer(context, "player");
                            String picked = AILMENTS[
                                IntegerArgumentType.getInteger(context, "disease") % AILMENTS.length];
                            give(target, picked);
                            context.getSource().sendSuccess(
                                () -> Component.literal(target.getName().getString() + " получил(а): " + picked), true);
                            return 1;
                        }))))
            .then(Commands.literal("cure")
                .executes(context -> cure(context.getSource(), context.getSource().getPlayerOrException()))
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(context -> cure(context.getSource(), EntityArgument.getPlayer(context, "player"))))));
    }

    private static void give(ServerPlayer target, String disease) {
        CompoundTag root = target.getPersistentData();
        CompoundTag data = root.contains(ROOT_KEY) ? root.getCompound(ROOT_KEY) : new CompoundTag();
        if (!root.contains(ROOT_KEY)) {
            root.put(ROOT_KEY, data);
        }
        data.putString(KEY_DISEASE, disease);
        target.sendSystemMessage(Component.literal(announce(disease)));
    }

    private static int cure(CommandSourceStack source, ServerPlayer target) {
        CompoundTag root = target.getPersistentData();
        if (root.contains(ROOT_KEY)) {
            CompoundTag data = root.getCompound(ROOT_KEY);
            data.putString(KEY_DISEASE, "");
            data.putInt(KEY_TIMER, 0);
            data.putBoolean(KEY_PREV_SPRINT, false);
        }
        target.setAirSupply(target.getMaxAirSupply());
        final String name = target.getName().getString();
        source.sendSuccess(() -> Component.literal(name + " вылечен(а). Болезни сняты."), true);
        return 1;
    }
}
