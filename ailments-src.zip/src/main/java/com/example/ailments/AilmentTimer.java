package com.example.ailments;

import java.util.Random;

import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

public class AilmentTimer {

    /** Раз в сколько тиков идёт проверка. 20 тиков = 1 сек, 6000 = 5 минут. */
    public static int intervalTicks = 6000;
    /** Шанс заразиться за проверку, в процентах. */
    public static int chancePercent = 30;

    private static final String TIMER_KEY = "AilmentTimerTicks";
    private static final String ACTIVE_KEY = "AilmentActive";
    private static final String PREV_SPRINT_KEY = "AilmentPrevSprint";
    private static final Random RANDOM = new Random();
    private static final String[] AILMENTS = {"asthma", "fever", "vertigo"};

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide || player.isCreative() || player.isSpectator()) return;

        CompoundTag data = player.getPersistentData();

        // хроническая болезнь уже есть — она не кончается сама
        String active = data.getString(ACTIVE_KEY);
        if (!active.isEmpty()) {
            tickAilment(player, active, data);
            return;
        }

        // проверки здоровья нет: раз в interval тиков — шанс заболеть
        int ticks = data.getInt(TIMER_KEY) + 1;
        if (ticks >= intervalTicks) {
            ticks = 0;
            if (RANDOM.nextInt(100) < chancePercent) {
                String next = AILMENTS[RANDOM.nextInt(AILMENTS.length)];
                data.putString(ACTIVE_KEY, next);
                player.sendSystemMessage(Component.literal(announce(next)));
            }
        }
        data.putInt(TIMER_KEY, ticks);
    }

    private static void tickAilment(Player player, String ailment, CompoundTag data) {
        switch (ailment) {
            case "asthma" -> {
                boolean sprinting = player.isSprinting();
                if (sprinting) {
                    // бег "сжигает" воздух, как под водой
                    int air = Math.max(0, player.getAirSupply() - 2);
                    player.setAirSupply(air);
                    if (air <= 60) {
                        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, true, false));
                    }
                    if (air <= 20) {
                        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, true, false));
                    }
                    if (air == 0) {
                        player.hurt(player.damageSources().drown(), 1.0F);
                    }
                } else {
                    // стоишь — воздух восстанавливается
                    if (player.getAirSupply() < player.getMaxAirSupply()) {
                        player.setAirSupply(Math.min(player.getMaxAirSupply(), player.getAirSupply() + 2));
                    }
                    // резко остановился после бега — одышка
                    if (data.getBoolean(PREV_SPRINT_KEY)) {
                        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0, true, false));
                    }
                }
                data.putBoolean(PREV_SPRINT_KEY, sprinting);
            }
            case "fever" -> {
                if (player.tickCount % 200 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 400, 0, true, false));
                    if (RANDOM.nextInt(3) == 0) {
                        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 300, 0, true, false));
                    }
                }
            }
            case "vertigo" -> {
                if (player.tickCount % 300 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0, true, false));
                    if (RANDOM.nextInt(4) == 0) {
                        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1, true, false));
                    }
                }
            }
        }
    }

    private static String announce(String ailment) {
        return switch (ailment) {
            case "asthma" -> "Сжимается в груди... астма. Бег теперь даётся тяжело.";
            case "fever" -> "Ты чувствуешь жар — голодаешь и слабеешь. Лихорадка!";
            case "vertigo" -> "Мир плывёт перед глазами — головокружение!";
            default -> ailment;
        };
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
            .requires(source -> source.hasPermission(2))
            .then(Commands.literal("cure")
                .executes(context -> cure(context.getSource(), context.getSource().getPlayerOrException()))
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(context -> cure(context.getSource(), EntityArgument.getPlayer(context, "player")))))
            .then(Commands.literal("interval")
                .then(Commands.argument("minutes", IntegerArgumentType.integer(1, 60))
                    .executes(context -> {
                        intervalTicks = IntegerArgumentType.getInteger(context, "minutes") * 60 * 20;
                        context.getSource().sendSuccess(
                            () -> Component.literal("Интервал болезней: " + (intervalTicks / 1200) + " мин."), true);
                        return 1;
                    })))
            .then(Commands.literal("chance")
                .then(Commands.argument("percent", IntegerArgumentType.integer(0, 100))
                    .executes(context -> {
                        chancePercent = IntegerArgumentType.getInteger(context, "percent");
                        context.getSource().sendSuccess(
                            () -> Component.literal("Шанс заразиться: " + chancePercent + "%"), true);
                        return 1;
                    })))
            .then(Commands.literal("give")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("ailment", IntegerArgumentType.integer(0, 2))
                        .executes(context -> {
                            Player target = EntityArgument.getPlayer(context, "player");
                            String ailment = AILMENTS[IntegerArgumentType.getInteger(context, "ailment")];
                            target.getPersistentData().putString(ACTIVE_KEY, ailment);
                            target.sendSystemMessage(Component.literal(announce(ailment)));
                            context.getSource().sendSuccess(
                                () -> Component.literal("Выдал " + ailment + " игроку " + target.getName().getString()), true);
                            return 1;
                        })))));
    }

    private static int cure(CommandSourceStack source, Player target) {
        CompoundTag data = target.getPersistentData();
        data.putString(ACTIVE_KEY, "");
        data.putInt(TIMER_KEY, 0);
        data.putBoolean(PREV_SPRINT_KEY, false);
        source.sendSuccess(() -> Component.literal("Игрок " + target.getName().getString() + " вылечен."), true);
        return 1;
    }
}
