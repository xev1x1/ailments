package com.example.ailments;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod(Ailments.MODID)
public class Ailments {
    public static final String MODID = "ailments";

    public Ailments(IEventBus modEventBus) {
        NeoForge.EVENT_BUS.register(AilmentTimer.class);
    }
}
