package com.example.ailments;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(Ailments.MODID)
public class Ailments {
    public static final String MODID = "ailments";

    public Ailments(IEventBus modEventBus) {
        // Обработчики событий регистрируются автоматически через @EventBusSubscriber
    }
}
