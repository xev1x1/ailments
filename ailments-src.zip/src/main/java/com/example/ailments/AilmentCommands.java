package com.example.ailments;

import java.util.Collection;

import com.mojang.brigadier.CommandDispatcher;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = Ailments.MODID)
public final class AilmentCommands {

    private AilmentCommands() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("ailments")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("give")
                        .then(Commands.argument("target", EntityArgument.players())
                                .then(Commands.literal("asthma")
                                        .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayers(ctx, "target"), "asthma")))
                                .then(Commands.literal("arthritis")
                                        .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayers(ctx, "target"), "arthritis")))
                                .then(Commands.literal("anemia")
                                        .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayers(ctx, "target"), "anemia")))
                                .then(Commands.literal("none")
                                        .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayers(ctx, "target"), "none")))))
                .then(Commands.literal("list").executes(ctx -> {
                    CommandSourceStack source = ctx.getSource();
                    ServerPlayer self = source.getPlayerOrException();
                    String ailment = AilmentEvents.getAilment(self);
                    String shown = ailment.isEmpty() ? "здоров" : ailment;
                    source.sendSuccess(() -> Component.literal("§7Твоя болезнь: §f" + shown), false);
                    return 1;
                })));
    }

    private static int give(CommandSourceStack source, Collection<ServerPlayer> targets, String ailment) {
        for (ServerPlayer player : targets) {
            AilmentEvents.setAilment(player, ailment.isEmpty() ? null : ailment);
        }
        String shown = "none".equals(ailment) ? "здоров(а)" : ailment;
        source.sendSuccess(() -> Component.literal(
                "§aВыдана болезнь §f" + shown + "§a игрокам: §f" + targets.size()), true);
        return 1;
    }
}
