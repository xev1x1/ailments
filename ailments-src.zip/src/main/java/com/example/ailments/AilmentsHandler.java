package com.example.ailments;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

public class AilmentsHandler {

    public static final String ASTHMA = "asthma";
    public static final String ARTHRITIS = "arthritis";
    public static final String ANEMIA = "anemia";

    private static final ResourceLocation ANEMIA_HEALTH =
            ResourceLocation.fromNamespaceAndPath(AilmentsMod.MODID, "anemia_health");

    private static final int ASTHMA_RUN_LIMIT = 160;    // 8 секунд бега до приступа
    private static final int ASTHMA_JUMP_COST = 10;     // прыжок откусывает 0,5 с
    private static final int ASTHMA_ATTACK_TICKS = 100; // приступ: 5 секунд
    private static final int ASTHMA_RECOVER = 2;        // восстановление за пределами бега

    private static final double ARTHRITIS_FALL_MIN = 2.0;
    private static final double ARTHRITIS_FALL_CHANCE = 0.5;

    private final Map<UUID, Integer> asthmaRun = new HashMap<>();
    private final Map<UUID, Double> airPeakY = new HashMap<>();

    public static boolean has(Player player, String ailment) {
        return player.getPersistentData().getBoolean("ailments_" + ailment);
    }

    public static void give(Player player, String ailment) {
        player.getPersistentData().putBoolean("ailments_" + ailment, true);
        if (ANEMIA.equals(ailment)) {
            applyAnemia(player);
        }
        player.displayClientMessage(Component.literal(
                "§e[ailments]§f Выдан недуг: " + ailment), true);
    }

    public static void clearAll(Player player) {
        for (String a : new String[]{ASTHMA, ARTHRITIS, ANEMIA}) {
            player.getPersistentData().remove("ailments_" + a);
        }
        removeAnemia(player);
        player.displayClientMessage(Component.literal(
                "§e[ailments]§f Все недуги сняты."), true);
    }

    private static void applyAnemia(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && attr.getModifier(ANEMIA_HEALTH) == null) {
            attr.addTransientModifier(new AttributeModifier(
                    ANEMIA_HEALTH, -8.0, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    private static void removeAnemia(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            attr.removeModifier(ANEMIA_HEALTH);
        }
    }

    private static String bar(int filled, int total) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < total; i++) {
            sb.append(i < filled ? "▮" : "▯");
        }
        return sb.toString();
    }

    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.entity.level().isClientSide) {
            return;
        }
        Player player = event.entity;
        UUID id = player.getUUID();

        if (has(player, ASTHMA)) {
            int t = asthmaRun.getOrDefault(id, 0);
            if (player.isSprinting()) {
                t++;
                if (t >= ASTHMA_RUN_LIMIT && !player.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)) {
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ASTHMA_ATTACK_TICKS, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ASTHMA_ATTACK_TICKS, 0));
                    player.displayClientMessage(Component.literal("§cПриступ астмы! Трудно дышать."), true);
                    t = 0;
                } else if (t > 0 && t % 20 == 0) {
                    int filled = Math.max(1, 10 - (t * 10 / ASTHMA_RUN_LIMIT));
                    player.displayClientMessage(Component.literal(
                            "§7Дыхание: §c" + bar(filled, 10)), true);
                }
            } else if (!player.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)) {
                t = Math.max(0, t - ASTHMA_RECOVER);
            }
            asthmaRun.put(id, t);
        }

        if (has(player, ARTHRITIS)) {
            if (!player.onGround()) {
                airPeakY.merge(id, player.getY(), Math::max);
            } else {
                Double peak = airPeakY.remove(id);
                if (peak != null) {
                    double fall = peak - player.getY();
                    if (fall >= ARTHRITIS_FALL_MIN && player.getRandom().nextDouble() < ARTHRITIS_FALL_CHANCE) {
                        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
                        player.displayClientMessage(Component.literal(
                                "§6Колени хрустнули! С каждым шагом простреливает."), true);
                    }
                }
            }
            if (player.isSprinting() && player.getRandom().nextFloat() < 0.0005f) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 0));
                player.displayClientMessage(Component.literal("§6Колени ноют..."), true);
            }
        }

        if (has(player, ANEMIA) && player.isSprinting()) {
            player.causeFoodExhaustion(0.08f);
            if (player.getRandom().nextFloat() < 0.002f) {
                player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 40, 0));
            }
        }
    }

    @SubscribeEvent
    public void onJump(LivingEvent.LivingJumpEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        if (event.getEntity().level().isClientSide) {
            return;
        }
        if (!has(player, ASTHMA) || player.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)) {
            return;
        }
        asthmaRun.merge(player.getUUID(), ASTHMA_JUMP_COST, Integer::sum);
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof Player player && has(player, ANEMIA)) {
            applyAnemia(player);
        }
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ailments")
            .then(Commands.literal("give")
                .then(Commands.argument("ailment", StringArgumentType.word())
                    .then(Commands.argument("targets", EntityArgument.players())
                        .executes(ctx -> {
                            String ailment = StringArgumentType.getString(ctx, "ailment");
                            Collection<Player> targets = EntityArgument.getPlayers(ctx, "targets");
                            for (Player p : targets) {
                                give(p, ailment);
                            }
                            return 1;
                        }))))
            .then(Commands.literal("clear")
                .then(Commands.argument("targets", EntityArgument.players())
                    .executes(ctx -> {
                        for (Player p : EntityArgument.getPlayers(ctx, "targets")) {
                            clearAll(p);
                        }
                        return 1;
                    }))));
    }
}
