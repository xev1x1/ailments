package com.example.ailments;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.living.LivingJumpEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Три болезни: asthma (астма), arthritis (артрит), anemia (анемия).
 * Болезнь хранится в PersistentData игрока — переживает перезаход.
 */
@EventBusSubscriber(modid = Ailments.MODID)
public final class AilmentEvents {

    public static final ResourceLocation AILMENT_KEY =
            ResourceLocation.fromNamespaceAndPath(Ailments.MODID, "ailment");

    private static final ResourceLocation ANEMIA_HEALTH_ID =
            ResourceLocation.fromNamespaceAndPath(Ailments.MODID, "anemia_health");

    // ---- астма ----
    private static final int ASTHMA_SPRINT_LIMIT = 160; // 160 тиков = 8 секунд бега
    private static final int ASTHMA_PAUSE_TICKS  = 100; // 5 секунд отдышаться
    private static final int ASTHMA_JUMP_COST    = 10;  // прыжок приближает приступ
    private static final int ASTHMA_AIR_DRAIN    = 6;   // насколько быстро тратятся пузырьки

    // ---- артрит ----
    private static final double ARTHRITIS_SPRINT_FLARE_CHANCE = 0.0005; // шанс за тик бега
    private static final double ARTHRITIS_JUMP_FLARE_CHANCE   = 0.15;
    private static final double ARTHRITIS_FALL_FLARE_CHANCE   = 0.35;

    // ---- анемия ----
    private static final double ANEMIA_HEALTH_LOSS  = 8.0;  // минус 4 сердца
    private static final double ANEMIA_FAINT_CHANCE = 0.0015; // шанс потемнения в глазах за тик бега
    private static final float ANEMIA_EXTRA_EXHAUSTION = 0.01f;

    /** 0 — тики бега, 1 — оставшиеся тики приступа астмы */
    private static final Map<UUID, int[]> STATE = new HashMap<>();

    private AilmentEvents() {}

    public static String getAilment(Player player) {
        return player.getPersistentData().getString(AILMENT_KEY.toString());
    }

    public static void setAilment(Player player, String id) {
        var data = player.getPersistentData();
        if (id == null || id.isEmpty()) {
            if (data.contains(AILMENT_KEY.toString())) {
                data.remove(AILMENT_KEY.toString());
            }
            removeAnemiaModifier(player);
        } else {
            data.putString(AILMENT_KEY.toString(), id);
            if ("anemia".equals(id)) {
                applyAnemiaModifier(player);
            }
        }
        STATE.remove(player.getUUID());
        player.removeEffects(); // сбросить эффекты прошлой болезни
    }

    private static int[] state(Player player) {
        return STATE.computeIfAbsent(player.getUUID(), u -> new int[2]);
    }

    // ================= ТИК =================
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;

        String ailment = getAilment(player);
        switch (ailment) {
            case "asthma" -> tickAsthma(player);
            case "arthritis" -> tickArthritis(player);
            case "anemia" -> tickAnemia(player);
            default -> { /* здоров */ }
        }
    }

    // ================= АСТМА =================
    private static void tickAsthma(Player player) {
        int[] s = state(player);

        if (s[1] > 0) { // идёт приступ — бежать нельзя
            s[1]--;
            if (player.isSprinting()) {
                player.setSprinting(false);
            }
            return;
        }

        if (!player.isSprinting()) {
            s[0] = Math.max(0, s[0] - 2); // покой восстанавливает запас
            return;
        }

        s[0]++;
        if (player.getAirSupply() > 0) {
            player.setAirSupply(Math.max(0, player.getAirSupply() - ASTHMA_AIR_DRAIN));
        }

        if (s[0] >= ASTHMA_SPRINT_LIMIT) {
            s[0] = 0;
            s[1] = ASTHMA_PAUSE_TICKS;
            player.setSprinting(false);
            player.setAirSupply(30);
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ASTHMA_PAUSE_TICKS, 1));
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ASTHMA_PAUSE_TICKS, 0));
            player.displayClientMessage(
                    Component.literal("§cПриступ астмы! Остановись и отдышись (~5 секунд)."), true);
        }
    }

    // ================= АРТРИТ =================
    private static void tickArthritis(Player player) {
        if (!player.isSprinting()) return;
        if (player.getRandom().nextDouble() < ARTHRITIS_SPRINT_FLARE_CHANCE) {
            flare(player, "§eСуставы скрутило — бегать сейчас тяжело.");
        }
    }

    private static void flare(Player player, String message) {
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 0));
        player.displayClientMessage(Component.literal(message), true);
    }

    // ================= АНЕМИЯ =================
    private static void tickAnemia(Player player) {
        applyAnemiaModifier(player);

        if (player.isSprinting()) {
            player.causeFoodExhaustion(ANEMIA_EXTRA_EXHAUSTION);
            if (player.getRandom().nextDouble() < ANEMIA_FAINT_CHANCE) {
                player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                player.displayClientMessage(
                        Component.literal("§cВ глазах потемнело... стоит передохнуть."), true);
            }
        }
    }

    private static void applyAnemiaModifier(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null && attr.getModifier(ANEMIA_HEALTH_ID) == null) {
            attr.addPermanentModifier(new AttributeModifier(
                    ANEMIA_HEALTH_ID, -ANEMIA_HEALTH_LOSS, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    private static void removeAnemiaModifier(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            attr.removeModifier(ANEMIA_HEALTH_ID);
        }
    }

    // ================= ПРЫЖОК =================
    @SubscribeEvent
    public static void onJump(LivingJumpEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.level().isClientSide()) return;

        String ailment = getAilment(player);
        if ("asthma".equals(ailment)) {
            if (player.isSprinting()) {
                state(player)[0] += ASTHMA_JUMP_COST; // бег в припрыжку быстрее приводит к приступу
            }
        } else if ("arthritis".equals(ailment)) {
            if (player.getRandom().nextDouble() < ARTHRITIS_JUMP_FLARE_CHANCE) {
                flare(player, "§eКолени хрустнули — прыгать больно.");
            }
        }
    }

    // ================= ПАДЕНИЕ =================
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.level().isClientSide()) return;
        if (!"arthritis".equals(getAilment(player))) return;

        if (event.getFallDistance() > 2.5f && player.getRandom().nextDouble() < ARTHRITIS_FALL_FLARE_CHANCE) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            player.displayClientMessage(
                    Component.literal("§eСуставы заныли после падения."), true);
        }
    }
}
