package com.example.ailments;

import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod(AilmentsMod.MODID)
public class AilmentsMod {
    public static final String MODID = "ailments";

    public AilmentsMod() {
        NeoForge.EVENT_BUS.register(new AilmentsHandler());
    }
}
